F-Secure Decryptor For Mira Ransomware
==================
F-Secure Decryptor For Mira Ransomware | Copyright � 2019 F-Secure Corporation. All Rights Reserved


F-Secure Decryptor for Mira Ransomware helps you decrypt files that were encrypted by the ransomware known as Mira.

It is important to run the tool on the specific computer where the files were originally encrypted. This is because the recovery key for each files are calculated from the computer where the files got encrypted.

This tool requires Administrator rights in order to execute properly. 

NOTE: This is an F-Secure Labs support tool. It is provided "as is" without warranty or product support. 

How to use the decryptor tool for Mira Ransomware
=========================================
   
  1. Extract the package "F-SecureDecryptorForMiraRansomware.zip" to any folder.
  2. On the same folder location where the tool was extracted, open up a command line and run it with "Administrator" priviledge.  Here's an example how:
    2.a: Press "Window" button + "R" together to open up a Run dialogue
    2.b: Enter this command <runas /user:Administrator "%comspec% /K \"cd %~dp0 \" ">
    2.c: Change "/user:Administrator" to the actual administrator account of the machine as necessary  
    2.d: Enter the password of the Administrator user
  3. Run the tool "F-SecureDecryptorForMiraRansomware.exe"
  4. The tool prints USAGE and exit if arguments are not provided:
	4.a: /decrypt - Search for encrypted files and decrypt them
	4.b: /nolog   - This flag suppresses log file creation
	4.c: /nobackup - This flag suppresses backup creation
	4.d: /accepteult -  This flag suppresses the display of the license
  5. The tool will automatically search for all encrypted files in the system and will decrypt the encrypted files.
  
  A small video on how the tool works in action: 
  https://www.youtube.com/watch?v=WhTKSTQCGqM

--------------------------- 
https://www.f-secure.com
"Cyber Security Lives Here"    

---
End of document
